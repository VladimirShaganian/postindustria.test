-- Adminer 4.2.4 MySQL dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

DROP TABLE IF EXISTS `companies`;
CREATE TABLE `companies` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(40) NOT NULL,
  `quota` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO `companies` (`id`, `name`, `quota`) VALUES
(58,	'SpaceX',	200),
(56,	'Google',	100),
(53,	'Microsoft',	201),
(57,	'Facebook',	234);

DROP TABLE IF EXISTS `transfer_logs`;
CREATE TABLE `transfer_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `date_create` datetime NOT NULL,
  `resource` tinytext NOT NULL,
  `transfered` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL,
  `email` varchar(80) NOT NULL,
  `company_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO `users` (`id`, `name`, `email`, `company_id`) VALUES
(15,	'Elon Musk',	'elon@space.com',	58),
(16,	'Larry Page',	'larry@gmail.com',	56),
(17,	'Sergey Brin',	'brin@gmail.com',	56),
(18,	'Bill Gates',	'billgates@microsoft.com',	53),
(19,	'Mark Zuckerberg',	'markzuckerberg@facebook.com',	57),
(13,	'asdf',	'test@test.com',	54);

-- 2017-01-16 15:31:39
